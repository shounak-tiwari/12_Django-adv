import random
from django.core.mail import send_mail
from django.conf import settings
from .models import CustomUser
from django.utils import timezone
from datetime import timedelta
import logging

logger = logging.getLogger(__name__)

def generate_otp():
    return str(random.randint(100000, 999999))

def send_otp_email(email):
    try:
        user = CustomUser.objects.get(email=email)
        otp = generate_otp()
        user.otp = otp
        user.otp_created_at = timezone.now()
        user.save()
        
        subject = 'Verify Your Email Address'
        message = f'Your OTP for email verification is: {otp}'
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [email]
        
        send_mail(subject, message, email_from, recipient_list)
        return True
    except Exception as e:
        logger.error(f"Error sending OTP email: {str(e)}")
        return False

def is_otp_expired(user):
    if not user.otp_created_at:
        return True
    expiration_time = user.otp_created_at + timedelta(minutes=5)
    return timezone.now() > expiration_time