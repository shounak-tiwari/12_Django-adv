from django.urls import path
from .views import item_list, item_update, Item_create,item_delete,homepage



from .authentication import (
    RegisterView,
    LoginView,
    VerifyAccountView,
    LogoutView,
    HomeView,
    ResendOTPView,
    index,
    pyscript
)

from .deshboard import AdminDeshboard,acceptrequest,deactivateaccount

urlpatterns = [
    path('',homepage,name='homepage'),
    path('item_list/',item_list,name='item_list'),
    path('add/',Item_create,name="Item_create"),
    path('edit/<int:id>/',item_update,name='item_update'),
    path('delete/<int:id>',item_delete,name="item_delete"),
    path('index/',homepage,name='homepage'),
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('verify-email/', VerifyAccountView.as_view(), name='verify-email'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('', HomeView.as_view(), name='home'),
    path('resend-otp/', ResendOTPView.as_view(), name='resend-otp'),
    path('home/',index,name='index'),
    path('admin',AdminDeshboard,name="AdminDeshboard"),
    path('acceptrequest/<int:id>',acceptrequest,name="acceptrequest"),
    path('deactivateaccount/<int:id>',deactivateaccount,name="deactivateaccount")
]
