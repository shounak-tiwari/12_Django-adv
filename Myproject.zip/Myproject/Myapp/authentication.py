from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate, login, logout
from .serializers import UserRegisterSerializer, UserLoginSerializer, VerifyAccountSerializer
from .utils import send_otp_email, is_otp_expired
from .models import CustomUser
from rest_framework.permissions import IsAuthenticated, AllowAny
from django.shortcuts import render, redirect
from django.views import View
from django.shortcuts import render, redirect
from django.contrib.auth import get_user_model
from django.contrib import messages
from .utils import send_otp_email

CustomUser = get_user_model()

class RegisterView(View):
    def get(self, request):
        return render(request, 'register.html')

    def post(self, request):
        email = request.POST.get('email')
        username = request.POST.get('username')
        phone_number = request.POST.get('phone_number')
        password = request.POST.get('password')
        registertype = request.POST.get('registertype')

        if not all([email, username, phone_number, password]):
            return render(request, 'register.html', {
                'message': 'All fields are required.',
                'status': 'error'
            })

        if CustomUser.objects.filter(email=email).exists():
            return render(request, 'register.html', {
                'message': 'Email already exists.',
                'status': 'error'
            })

        if CustomUser.objects.filter(username=username).exists():
            return render(request, 'register.html', {
                'message': 'Username already exists.',
                'status': 'error'
            })

        user = CustomUser.objects.create_user(
            email=email,
            username=username,
            phone_number=phone_number,
            password=password,
            registertype=registertype
        )
        
        send_otp_email(user.email)

        return render(request, 'verify_email.html', {
            'message': 'Registration successful! Please check your email for the OTP.',
            'status': 'success'
        })
class LoginView(APIView):
    permission_classes = [AllowAny]
    
    def post(self, request):
        serializer = UserLoginSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'status': 'error',
                'errors': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)
            
        email = serializer.validated_data['email']
        password = serializer.validated_data['password']
        
        user = authenticate(request, email=email, password=password)
        
        if not user:
            return Response({
                'status': 'error',
                'message': 'Invalid credentials'
            }, status=status.HTTP_401_UNAUTHORIZED)
            
        if not user.is_verified:
            return Response({
                'status': 'error',
                'message': 'Email not verified. Please verify your email first.'
            }, status=status.HTTP_401_UNAUTHORIZED)
            
        login(request, user)
        token, created = Token.objects.get_or_create(user=user)
        return Response({
            'status': 'success',
            'message': 'Login successful',
            'data': {
                'token': token.key,
                'email': user.email,
                'username': user.username
            }
        })
    
    def get(self, request):
        return render(request, 'login.html')

class VerifyAccountView(APIView):
    permission_classes = [AllowAny]
    
    def post(self, request):
        serializer = VerifyAccountSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'status': 'error',
                'errors': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)
            
        email = serializer.validated_data['email']
        otp = serializer.validated_data['otp']
        
        try:
            user = CustomUser.objects.get(email=email)
        except CustomUser.DoesNotExist:
            return Response({
                'status': 'error',
                'message': 'User not found'
            }, status=status.HTTP_404_NOT_FOUND)
        
        if is_otp_expired(user):
            return Response({
                'status': 'error',
                'message': 'OTP has expired. Please request a new one.'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        if user.otp != otp:
            return Response({
                'status': 'error',
                'message': 'Invalid OTP'
            }, status=status.HTTP_400_BAD_REQUEST)
            
        user.is_verified = True
        user.otp = None
        user.otp_created_at = None
        user.save()
        
        return Response({
            'status': 'success',
            'message': 'Email verified successfully'
        })
    
    def get(self, request):
        return render(request, 'verify_email.html')

class LogoutView(APIView):
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        request.user.auth_token.delete()
        logout(request)
        return Response({
            'status': 'success',
            'message': 'Logout successful'
        })
    
    def get(self, request):
        logout(request)
        return redirect('login')

class HomeView(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        return render(request, 'home.html')





class ResendOTPView(APIView):
    permission_classes = [AllowAny]
    
    def post(self, request):
        email = request.data.get('email')
        if not email:
            return Response({
                'status': 'error',
                'message': 'Email is required'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            user = CustomUser.objects.get(email=email)
        except CustomUser.DoesNotExist:
            return Response({
                'status': 'error',
                'message': 'User not found'
            }, status=status.HTTP_404_NOT_FOUND)
        
        if user.is_verified:
            return Response({
                'status': 'error',
                'message': 'Email is already verified'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        send_otp_email(email)
        return Response({
            'status': 'success',
            'message': 'New OTP sent to your email'
        })
    
    def get(self, request):
        return render(request, 'resend_otp.html')
    



def index(request):
    return render(request,'home.html')

def pyscript(request):
    pass