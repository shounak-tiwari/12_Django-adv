from django.shortcuts import render, redirect, get_object_or_404
from .models import CustomUser, Item
from django.http import HttpResponse

def AdminDeshboard(request):
    # Get all items
    items = Item.objects.all()

    # Filter users based on registertype
    user_requests = CustomUser.objects.filter(registertype='user')
    staff_requests = CustomUser.objects.filter(registertype='staff')
    superuser_requests = CustomUser.objects.filter(registertype='superuser')

    context = {
        'user_requests': user_requests,
        'staff_requests': staff_requests,
        'superuser_requests': superuser_requests,
        'items': items,
    }

    return render(request, 'deshboard.html', context)




def acceptrequest(request, id):
    if request.method == 'POST':
        user = get_object_or_404(CustomUser, id=id)

        if user.registertype == 'superuser':
            user.is_superuser = True
            user.is_staff = True
        elif user.registertype == 'staff':
            user.is_staff = True
           
        user.is_active = True
        user.save()
    return redirect('AdminDeshboard')  # Update if your URL name differs



def deactivateaccount(request,id):
    if request.method == 'POST':
        user = get_object_or_404(CustomUser, id=id)

        if user.registertype == 'superuser':
            user.is_superuser = False
            user.is_staff = False
        elif user.registertype == 'staff':
            user.is_staff = False
           
        user.is_active = False
        user.save()
    return redirect('AdminDeshboard')  # Update if your URL name differs
